
<?php
 script('reportgenerator', 'script');
 $users=$_[0];
 $projects=$_['proj'];
 $category=$_[1];
 unset($users['tescior']);
 unset($users['system']);
 array_multisort($users);
 array_push($category, '');
 array_multisort($category);
 date_default_timezone_set("Europe/Warsaw");
 ?>
 <form method='POST'  action="/index.php/apps/reportgenerator/page">
   <input type="hidden" name="requesttoken" value="<?php p($_['requesttoken']); ?>" />
   <label for="projects" class="navimenu"><b>WYBIERZ PROJEKT:</b></label><br>
   <select name="projects" id="projects">
    <?php
      foreach($projects as $key => $value)
      {
        echo "<option value='$value'"; 
        if($_POST['project']==$value) echo " selected ";
        echo ">".$value."</option>";
      }
   ?>
  </select>
  
 </form>
<div>
  <hr>
</div>

 <form method='POST'  action="/index.php/apps/reportgenerator/page">
   <input type="hidden" name="requesttoken" value="<?php p($_['requesttoken']); ?>" />
   <label for="contractnumber" class="navimenu"><b>NUMER UMOWY:</b></label><br>
   <input type="text" size="50" class="navimenu" id="contractnumber" name="contractnumber" required value="<?php if($_POST['contractnumber']) echo $_POST['contractnumber'];?>">

   <label for="contractdate" class="navimenu"><b>DATA UMOWY:</b></label><br>
   <input type="date" size="50" class="navimenu" id="contractdate" name="contractdate" required value="<?php if($_POST['contractdate']) echo $_POST['contractdate'];?>">
   <br>

   <label for="purchaser" class="navimenu"><b>ZAMAWIAJĄCY:</b></label><br>
   <input type="text" size="50" class="navimenu" id="purchaser" name="purchaser" required value="<?php if($_POST['purchaser']) echo $_POST['purchaser']; else echo"MIASTO KATOWICE, ul. Młyńska 4, 40-098 Katowice" ?>">
   <br>
	
   <label for="contractor" class="navimenu"><b>WYKONAWCA:</b></label><br>
   <input type="text" size="50" class="navimenu" id="contractor" name="contractor" required value="<?php if($_POST['contractor']) echo $_POST['contractor'];?>">
   <br>
 
   <label for="project" class="navimenu"><b>NAZWA OPRACOWANIA:</b></label><br>
   <input type="text" size="50" class="navimenu" id="project" name="project" required readonly value="<?php if($_POST['project']) echo $_POST['project']; if($_POST['projects']) echo $_POST['projects'];?>">
   <br>

   <label for="address" class="navimenu"><b>ADRES:</b></label><br>
   <input type="text" size="50" class="navimenu" id="address" name="address" required value="<?php if($_POST['address']) echo $_POST['address'];?>">
   <br>
   <hr>
   <input type="hidden" name="projects" value='<?php echo $_POST['projects'];?>'>
   <input type="submit" id="go2res"  value="GENERUJ">
 </form>
 
 
 
 
 