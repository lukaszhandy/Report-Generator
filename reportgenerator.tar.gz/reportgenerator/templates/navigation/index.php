
<?php
 
 $users=$_[0];
 $category=$_[1];
 unset($users['tescior']);
 unset($users['system']);
 array_multisort($users);
 array_push($category, '');
 array_multisort($category);
 date_default_timezone_set("Europe/Warsaw");
 ?>
 <form method='POST'  action="/index.php/apps/reportgenerator/page">
   <input type="hidden" name="requesttoken" value="<?php p($_['requesttoken']); ?>" />
   <label for="contractnumber" class="navimenu"><b>NUMER UMOWY:</b></label><br>
   <input type="text" size="50" class="navimenu" id="contractnumber" name="contractnumber" required value="<?php if($_POST['contractnumber']) echo $_POST['contractnumber'];?>">

   <label for="contractdate" class="navimenu"><b>DATA UMOWY:</b></label><br>
   <input type="date" size="50" class="navimenu" id="contractdate" name="contractdate" required value="<?php if($_POST['contractdate']) echo $_POST['contractdate'];?>">
   <br>

   <label for="purchaser" class="navimenu"><b>ZAMAWIAJĄCY:</b></label><br>
   <input type="text" size="50" class="navimenu" id="purchaser" name="purchaser" required value="<?php if($_POST['purchaser']) echo $_POST['purchaser']; else echo"MIASTO KATOWICE, ul. Młyńska 4, 40-098 Katowice" ?>">
   <br>
	
   <label for="contractor" class="navimenu"><b>WYKONAWCA:</b></label><br>
   <input type="text" size="50" class="navimenu" id="contractor" name="contractor" required value="<?php if($_POST['contractor']) echo $_POST['contractor'];?>">
   <br>
 
   <label for="project" class="navimenu"><b>NAZWA OPRACOWANIA:</b></label><br>
   <input type="text" size="50" class="navimenu" id="project" name="project" required value="<?php if($_POST['project']) echo $_POST['project'];?>">
   <br>

   <label for="address" class="navimenu"><b>ADRES:</b></label><br>
   <input type="text" size="50" class="navimenu" id="address" name="address" required value="<?php if($_POST['address']) echo $_POST['address'];?>">
   <br>
 
   <label for="stage" class="navimenu"><b>ETAP:</b></label><br>
   <select style="width: 270px;" name="stage" id="stage">
		<option  value=1 <?php if($_POST['stage']==1) echo ' selected '?>>Etap I</option>
		<option  value=2 <?php if($_POST['stage']==2) echo ' selected '?>>Etap II</option>
		<option  value=3 <?php if($_POST['stage']==3) echo ' selected '?>>Etap III</option>
		<option  value=4 <?php if($_POST['stage']==4) echo ' selected '?>>Wszystko</option>
   </select>
   <hr>
   <input type="submit" value="GENERUJ">
 </form>
 
 
 
 
 