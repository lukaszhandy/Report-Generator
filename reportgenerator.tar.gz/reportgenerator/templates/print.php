<?php 
    script('reportgenerator', 'print');
    style('reportgenerator', 'print');
    $lp=1; 
?>
<div class="container">
<table class="table">
    <tbody>
        <tr style="border-style:hidden;">
            <td class="middle">KZGM</td>
            <td class="righthead">Załącznik nr 4 do umowy: <?php echo $_POST['contractnumber'] ?> z dnia: <?php echo $_POST['contractdate']?></td>
        </tr>
    </tbody>
</table>
<center>
<h1>PROTOKÓŁ</h1>
<h2>PRZEKAZANIA DOKUMENTACJI</h2>
sporządzony w dniu: <?php echo date('Y-m-d'); ?><br><br><br>
</center>

<table class="table">
    <tbody>
        <tr class="middle">
            <td class="middle">ZAMAWIAJĄCY:</td>
            <td class="middle"><?php echo $_POST['purchaser']?></td>
        </tr>
        <tr class="middle">
            <td class="middle">WYKONAWCA:</td>
            <td class="middle"><?php echo $_POST['contractor']?></td>
        </tr>
        <tr class="middle">
            <td class="middle">NAZWA OPRACOWANIA:</td>
            <td class="middle"><?php echo $_POST['project']?></td>
        </tr>
        <tr class="middle">
            <td class="middle">ADRES:</td>
            <td class="middle"><?php echo $_POST['address']?></td>
        </tr>
        <tr class="middle">
            <td class="middle">ETAP:</td>
            <td class="middle">
                <?php 
                    if($_POST['stage']==1)
                        echo "I";
                    elseif($_POST['stage']==2)
                        echo "II";
                    elseif($_POST['stage']==3)
                        echo "III";
                    else
                        echo "I, II, III";
                ?>
            </td>
        </tr>
    </tbody>
</table>
<table class="table">
<thead>
    <tr >
        <th>NAZWA PLIKU / ŚCIEŻKA</th>
        <th>DATA ZAMIESZCZENIA</th>
    </tr>
</thead>
<tbody>
<?php
    if(!$_['dane'][0]) {
    ?>
    <tr class="main">
            <td class="main">BRAK DANYCH</td>
            <td class="main">BRAK DANYCH</td>
    </tr>
    <?php
        
    }
    else{
        foreach($_['dane'] as $data){
?>
<tr class="main">
            <td class="main"><?php echo $data['file'];?></td>
            <td class="main"><?php echo $data['data'];?></td>
</tr>
<?php
        }
    }
       
?>
</tbody>
</table>
<p>Protokół sporządzono w dwóch jednobrzmiących egzemplarzach.</p>
<br><br>
<table class="table">
    <tbody>
        <tr style="border-style:hidden;">
            <td >PODPISY ZAMAWIAJĄCEGO</td>
            <td>PODPISY WYKONAWCY</td>
        </tr>
    </tbody>
</table>
</div>