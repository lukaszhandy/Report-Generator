<?php
namespace OCA\ReportGenerator\Controller;

use OCP\IRequest;
use OCP\AppFramework\Http\TemplateResponse;
use OCP\AppFramework\Http\DataResponse;
use OCP\AppFramework\Controller;
use OCP\DB\QueryBuilder\IQueryBuilder;
use OCP\IDBConnection;

class PageController extends Controller {
	private $userId;
	protected $connection;

	public function __construct($AppName, IRequest $request, $UserId, IDBConnection $connection){
		parent::__construct($AppName, $request);
		$this->userId = $UserId;
		$this->connection=$connection;
	}

	/**
	 * CAUTION: the @Stuff turns off security checks; for this page no admin is
	 *          required and no CSRF check. If you don't know what CSRF is, read
	 *          it up in the docs or you might create a security hole. This is
	 *          basically the only required method to add this exemption, don't
	 *          add it to any other method if you don't exactly know what it does
	 *
	 * @NoAdminRequired
	 * @NoCSRFRequired
	 */
	public function index() {
		return new TemplateResponse('reportgenerator', 'index');  // templates/index.php
	}
	/**
	* @NoAdminRequired
	 */
	public function index2() {

		$index=0;
		$delRes=$this->getDelRes();
		$created=$this->getCreated();

		foreach($created as $row)
		{
			if($this->isDelRes($delRes, $row['id'])){

				$fileinfo=pathinfo($row['file']);
				//if($fileinfo['extension'] && strlen($fileinfo['extension'])<=4 && !(preg_match('#^ #',$fileinfo['extension'])) )
				if(preg_match('#^\S{3,4}#',$fileinfo['extension']))
        		{
					$result[$index]['file']=pathinfo(str_replace('/'.$_POST['project'].'/', '',$row['file']))['filename'].'.'.pathinfo(str_replace('/'.$_POST['project'].'/', '',$row['file']))['extension'];
					$result[$index]['dir']=pathinfo(str_replace('/'.$_POST['project'].'/', '',$row['file']))['dirname'];
				 	$result[$index]['data']=date('Y-m-d',$row['timestamp']);
				 	$result[$index]['timestamp']=$row['timestamp'];
				 	$result[$index]['id']=$row['object_id'];
				 	$index++;
				}	
			}
		}
		
		//exit;

		//print_r($created);
		//print_r($this->getDelRes()); // jako argument dać id i sprawdzać ostatnie wystąpienie w pliku lub sprawdzać dla tablicy // cyba lepiej dla tablicy bedzie szybckiej
		
		
		$res['dane']=$result;
		//$res[]=1;
		return new TemplateResponse('reportgenerator', 'print', $res);
	}
	public function isDelRes($delRes, $id)
	{
		$res=NULL;
		$filestate=1;
		foreach($delRes as $source)
		{
			if($source['id']==$id)
				$res=$source['type'];
		}
		if(!strcmp($res,'file_deleted'))
			$filestate=0;
		//echo $filestate.', '.$id.'<hr>';
		return $filestate;
	}
	protected function getDelRes(){
		$index=0;
		$querybuilder = $this->connection->getQueryBuilder();
        $querybuilder->select('*')->from('activity')
									->where("affecteduser Like :usera")
									->andwhere("file Like :fileF")
									->andwhere("type Like :typeF or type Like :typeF1")
									->orderby("timestamp")
									->setParameters(array('usera' => $this->userId,'fileF' => '/'.$_POST['project'].'/%', 'typeF'=>'%restored%','typeF1'=>'%deleted%' ));
		$queryresult =  $querybuilder->execute();
		foreach ($queryresult as $row) {

			date_default_timezone_set("Europe/Warsaw");
			
			$result[$index]['file']=$row['file'];
			$result[$index]['data']=date('Y-m-d',$row['timestamp']);
			$result[$index]['timestamp']=$row['timestamp'];
			$result[$index]['type']=$row['type'];
			$result[$index]['id']=$row['object_id'];

			$index++;
			
			//$date=date('Y-m-d',$row['timestamp']);
			//$date=date('Y-m-d H:i:s',$row['timestamp']);
			//$file=$row['file'];
			//$type=$row['type'];
			//echo $date.' - '.$file.' - ' .$type.'<hr>';
		}
									  
		if(!$result)
			$result[]=NULL;
		//echo "get data2: ".$this->userId;
		//print_r($result);
		return $result;
	}
	protected function getDeleted(){
		$index=0;
		$querybuilder = $this->connection->getQueryBuilder();
        $querybuilder->select('*')->from('activity')
									->where("affecteduser Like :usera")
									->andwhere("file Like :fileF")
									->andwhere("type Like :typeF")
									->orderby("file")
									->setParameters(array('usera' => $this->userId,'fileF' => '/'.$_POST['project'].'/%', 'typeF'=>'%deleted%'));
		$queryresult =  $querybuilder->execute();
		foreach ($queryresult as $row) {

			date_default_timezone_set("Europe/Warsaw");
			
			$result[$index]['file']=$row['file'];
			$result[$index]['data']=date('Y-m-d',$row['timestamp']);
			$result[$index]['timestamp']=$row['timestamp'];
			$result[$index]['id']=$row['object_id'];
			$index++;
			
			//$date=date('Y-m-d',$row['timestamp']);
			//$date=date('Y-m-d H:i:s',$row['timestamp']);
			//$file=$row['file'];
			//$type=$row['type'];
			//echo $date.' - '.$file.' - ' .$type.'<hr>';
		}
									  
		if(!$result)
			$result[]=NULL;
		//echo "get data2: ".$this->userId;
		//print_r($result);
		return $result;
	}
	protected function getCreated(){
		$index=0;
		$querybuilder = $this->connection->getQueryBuilder();
        $querybuilder->select('*')->from('activity')
									->where("affecteduser Like :usera")
									->andwhere("file Like :fileF")
									->andwhere("type Like :typeF")
									->orderby("file")
									->setParameters(array('usera' => $this->userId,'fileF' => '/'.$_POST['project'].'/%', 'typeF'=>'%created%'));
		$queryresult =  $querybuilder->execute();
		foreach ($queryresult as $row) {

			date_default_timezone_set("Europe/Warsaw");
			
			$result[$index]['file']=$row['file'];
			$result[$index]['data']=date('Y-m-d',$row['timestamp']);
			$result[$index]['timestamp']=$row['timestamp'];
			$result[$index]['id']=$row['object_id'];
			$index++;
			
			//$date=date('Y-m-d',$row['timestamp']);
			//$date=date('Y-m-d H:i:s',$row['timestamp']);
			//$file=$row['file'];
			//$type=$row['type'];
			//echo $date.' - '.$file.' - ' .$type.'<hr>';
		}
									  
		if(!$result)
			$result[]=NULL;
		//echo "get data2: ".$this->userId;
		//print_r($result);
		return $result;
	}
}
