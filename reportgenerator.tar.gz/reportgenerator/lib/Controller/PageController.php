<?php
namespace OCA\ReportGenerator\Controller;

use OCP\IRequest;
use OCP\AppFramework\Http\TemplateResponse;
use OCP\AppFramework\Http\DataResponse;
use OCP\AppFramework\Controller;
use OCP\DB\QueryBuilder\IQueryBuilder;
use OCP\IDBConnection;

use OCP\Files\StorageNotAvailableException;
use OCP\Files\StorageInvalidException;
use OC\Files\Filesystem;
use OC\Files\FileInfo;
use OC\Files\View;
use RecursiveDirectoryIterator;
use RecursiveIteratorIterator;

class PageController extends Controller {
	private $userId;
	protected $connection;

	public function __construct($AppName, IRequest $request, $UserId, IDBConnection $connection, Filesystem $filesystem, View $view){
		parent::__construct($AppName, $request);
		$this->userId = $UserId;
		$this->connection=$connection;
		$this->filesystem=$filesystem;
		$this->view=$view;
		$this->fileinfo=$fileinfo;
	}

	/**
	 * CAUTION: the @Stuff turns off security checks; for this page no admin is
	 *          required and no CSRF check. If you don't know what CSRF is, read
	 *          it up in the docs or you might create a security hole. This is
	 *          basically the only required method to add this exemption, don't
	 *          add it to any other method if you don't exactly know what it does
	 *
	 * @NoAdminRequired
	 * @NoCSRFRequired
	 */
	public function index() {
		$proj['proj']=$this->projects();
		
		//print_r($proj['proj']);

		$proj['subdir']=$this->subDir($this->projects());

		//echo "<hr>";

		//print_r($proj['subdir']);

		//exit;
		

		return new TemplateResponse('reportgenerator', 'index',$proj);  // templates/index.php
	}
	/**
	* @NoAdminRequired
	 */
	public function index3() {

		$proj['proj']=$this->projects();	
		return new TemplateResponse('reportgenerator', 'index',$proj);  // templates/index.php
	}

	/**
	* @NoAdminRequired
	 */
	public function index2() {
		
		//echo "test<hr>";
		$pathes=$_POST['projectsdetails'];
		//print_r($pathes);
		$localStorage='/var/www/html/nextcloud/data';
		$index=0;
		foreach($pathes as $subdir)
		{
			if(!strcmp($subdir,'.')){
				$path=$path=$localStorage.$this->filesystem->getRoot().'/'.$_POST['projects'].'/';
				$files=scandir($path);
				foreach($files as $file){
					if(is_file($path.'/'.$file)){
						$relPath=str_replace($localStorage.$this->filesystem->getRoot().'/'.$_POST['projects'].'/','',$file);
						//echo $path.' - '.date('Y-m-d',filectime($file)).'<br>';
						if(strtotime($_POST['datefrom'])<=strtotime((date('Y-m-d',filectime($path.'/'.$file))))
						&
						strtotime($_POST['dateto'])>=strtotime((date('Y-m-d',filectime($path.'/'.$file))))
						)
						{
							$result[$index]['file']=$file;
							$result[$index]['dir']=pathinfo($relPath)['dirname'];
							$result[$index]['data']=date('Y-m-d',filectime($path.'/'.$file));
							$index++;
						}


					 	//echo $file.'<br>';
					}
				}


				//echo "<hr>";
			}
			else{
				$path=$localStorage.$this->filesystem->getRoot().'/'.$_POST['projects'].'/'.$subdir.'/';
		
				$Directory = new RecursiveDirectoryIterator($path);
				$Iterator = new RecursiveIteratorIterator($Directory);

		//var_dump($Directory);
		//exit;
				foreach ($Iterator as $filename=>$cur) {
					if(is_file($filename)){
						$relPath=str_replace($localStorage.$this->filesystem->getRoot().'/'.$_POST['projects'].'/','',$filename);
						//echo $relPath.' - '.date('Y-m-d',filectime($filename)).'<br>';
						if(strtotime($_POST['datefrom'])<=strtotime((date('Y-m-d',filectime($filename))))
						&
						strtotime($_POST['dateto'])>=strtotime((date('Y-m-d',filectime($filename))))
						)
						{
							$result[$index]['file']=pathinfo($filename)['filename'].'.'.pathinfo($filename)['extension'];
							$result[$index]['dir']=pathinfo($relPath)['dirname'];
							$result[$index]['data']=date('Y-m-d',filectime($filename));
							$index++;
						}
						
					}	
				}
			}
		}

		
		//print_r($result);
		//exit;
	
		$dir=array_column($result,'dir');
		array_multisort($dir, SORT_ASC,  $result);
		$res['dane']=$result;
		//$res[]=1;
		return new TemplateResponse('reportgenerator', 'print', $res);
	}
	public function projects()
	{
		$localStorage='/var/www/html/nextcloud/data';
		$path=$localStorage.$this->filesystem->getRoot().'/'.$_POST['project'].'/';
		$dirs=(scandir($path));
		$res=null;
		foreach($dirs as $katalog => $prop)
		{
			if(is_dir($path.$prop) && !(!strcmp($prop,'.') || !strcmp($prop,'..')))
			$res[]=$prop;

		}
		return $res;
	}

	public function subDir($dir)
	{
		$localStorage='/var/www/html/nextcloud/data';
		//echo "<hr>SubDir BEG<hr>";
		foreach($dir as $dirs)
		{
			if($dir)
			{
				$subdir=null;
				$path=$localStorage.$this->filesystem->getRoot().'/'.$dirs.'/';
				
				//echo $dirs.'<br>';
				
				
				$subdir=(scandir($path));
				foreach($subdir as $subdirs => $name)
				{
					if(is_dir($path.$name) && !( !strcmp($name,'..')))
					{
						$res1[$dirs][]=$name;
						//echo $name.'<br>';
					}
				}

				//echo '<hr>';

				
			}
		}
		//print_r($res1);
		//echo "<hr>SubDir END<hr>";
		return $res1;
	}

	public function isDelRes($delRes, $id)
	{
		$res=NULL;
		$filestate=1;
		foreach($delRes as $source)
		{
			if($source['id']==$id)
				$res=$source['type'];
		}
		if(!strcmp($res,'file_deleted'))
			$filestate=0;
		//echo $filestate.', '.$id.'<hr>';
		return $filestate;
	}
	protected function getDelRes(){
		$index=0;
		$querybuilder = $this->connection->getQueryBuilder();
        $querybuilder->select('*')->from('activity')
									->where("affecteduser Like :usera")
									->andwhere("file Like :fileF")
									->andwhere("type Like :typeF or type Like :typeF1 or type Like :typeF2 or type Like :typeF3")
									->orderby("timestamp")
									->setParameters(array('usera' => $this->userId,'fileF' => '/'.$_POST['project'].'/%', 'typeF'=>'%restored%','typeF1'=>'%deleted%','typeF2'=>'%moved%', 'typeF3'=>'%renamed%' ));
		$queryresult =  $querybuilder->execute();
		foreach ($queryresult as $row) {

			date_default_timezone_set("Europe/Warsaw");
			
			$result[$index]['file']=$row['file'];
			$result[$index]['data']=date('Y-m-d',$row['timestamp']);
			$result[$index]['timestamp']=$row['timestamp'];
			$result[$index]['type']=$row['type'];
			$result[$index]['id']=$row['object_id'];

			$index++;
			
			//$date=date('Y-m-d',$row['timestamp']);
			//$date=date('Y-m-d H:i:s',$row['timestamp']);
			//$file=$row['file'];
			//$type=$row['type'];
			//echo $date.' - '.$file.' - ' .$type.'<hr>';
		}
									  
		if(!$result)
			$result[]=NULL;
		//echo "get data2: ".$this->userId;
		//print_r($result);
		return $result;
	}
	protected function getDeleted(){
		$index=0;
		$querybuilder = $this->connection->getQueryBuilder();
        $querybuilder->select('*')->from('activity')
									->where("affecteduser Like :usera")
									->andwhere("file Like :fileF")
									->andwhere("type Like :typeF")
									->orderby("file")
									->setParameters(array('usera' => $this->userId,'fileF' => '/'.$_POST['project'].'/%', 'typeF'=>'%deleted%'));
		$queryresult =  $querybuilder->execute();
		foreach ($queryresult as $row) {

			date_default_timezone_set("Europe/Warsaw");
			
			$result[$index]['file']=$row['file'];
			$result[$index]['data']=date('Y-m-d',$row['timestamp']);
			$result[$index]['timestamp']=$row['timestamp'];
			$result[$index]['id']=$row['object_id'];
			$index++;
			
			//$date=date('Y-m-d',$row['timestamp']);
			//$date=date('Y-m-d H:i:s',$row['timestamp']);
			//$file=$row['file'];
			//$type=$row['type'];
			//echo $date.' - '.$file.' - ' .$type.'<hr>';
		}
									  
		if(!$result)
			$result[]=NULL;
		//echo "get data2: ".$this->userId;
		//print_r($result);
		return $result;
	}
	protected function getCreated(){
		$index=0;
		$querybuilder = $this->connection->getQueryBuilder();
        $querybuilder->select('*')->from('activity')
									->where("affecteduser Like :usera")
									->andwhere("file Like :fileF")
									->andwhere("type Like :typeF")
									->orderby("file")
									->setParameters(array('usera' => $this->userId,'fileF' => '/'.$_POST['project'].'/%', 'typeF'=>'%created%'));
		$queryresult =  $querybuilder->execute();
		foreach ($queryresult as $row) {

			date_default_timezone_set("Europe/Warsaw");
			
			$result[$index]['file']=$row['file'];
			$result[$index]['data']=date('Y-m-d',$row['timestamp']);
			$result[$index]['timestamp']=$row['timestamp'];
			$result[$index]['id']=$row['object_id'];
			$index++;
			
			//$date=date('Y-m-d',$row['timestamp']);
			//$date=date('Y-m-d H:i:s',$row['timestamp']);
			//$file=$row['file'];
			//$type=$row['type'];
			//echo $date.' - '.$file.' - ' .$type.'<hr>';
		}
									  
		if(!$result)
			$result[]=NULL;
		//echo "get data2: ".$this->userId;
		//print_r($result);
		return $result;
	}
}
