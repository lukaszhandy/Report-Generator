<?php
namespace OCA\ReportGenerator\Controller;

use OCP\IRequest;
use OCP\AppFramework\Http\TemplateResponse;
use OCP\AppFramework\Http\DataResponse;
use OCP\AppFramework\Controller;
use OCP\DB\QueryBuilder\IQueryBuilder;
use OCP\IDBConnection;

class PageController extends Controller {
	private $userId;
	protected $connection;

	public function __construct($AppName, IRequest $request, $UserId, IDBConnection $connection){
		parent::__construct($AppName, $request);
		$this->userId = $UserId;
		$this->connection=$connection;
	}

	/**
	 * CAUTION: the @Stuff turns off security checks; for this page no admin is
	 *          required and no CSRF check. If you don't know what CSRF is, read
	 *          it up in the docs or you might create a security hole. This is
	 *          basically the only required method to add this exemption, don't
	 *          add it to any other method if you don't exactly know what it does
	 *
	 * @NoAdminRequired
	 * @NoCSRFRequired
	 */
	public function index() {
		return new TemplateResponse('reportgenerator', 'index');  // templates/index.php
	}
	/**
	* @NoAdminRequired
	 */
	public function index2() {
		$res['dane']=$this->getData();
		//$res[]=1;
		return new TemplateResponse('reportgenerator', 'print', $res);
	}

	protected function getData(){
		$index=0;
		$querybuilder = $this->connection->getQueryBuilder();
        $querybuilder->select('*')->from('activity')
									->where("affecteduser Like :usera")
									->andwhere("file Like :fileF")
									->andwhere("type Like :typeF")
									->orderby("file")
									->setParameters(array('usera' => $this->userId,'fileF' => '/'.$_POST['project'].'/%', 'typeF'=>'file_created'));
		$queryresult =  $querybuilder->execute();
		foreach ($queryresult as $row) {

			date_default_timezone_set("Europe/Warsaw");
			
			$result[$index]['file']=$row['file'];
			$result[$index]['data']=date('Y-m-d',$row['timestamp']);
			$index++;
			
			//$date=date('Y-m-d',$row['timestamp']);
			//$date=date('Y-m-d H:i:s',$row['timestamp']);
			//$file=$row['file'];
			//$type=$row['type'];
			//echo $date.' - '.$file.' - ' .$type.'<hr>';
		}
									  
		if(!$result)
			$result[]=NULL;
		//echo "get data2: ".$this->userId;
		//print_r($result);
		return $result;
	}
}
