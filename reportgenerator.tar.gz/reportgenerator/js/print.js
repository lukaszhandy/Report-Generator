setTimeout(function () { window.print(); }, 100);
setTimeout(function () { window.history.back(); }, 500);