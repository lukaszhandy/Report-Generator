function projects(){
    //window.alert("ooooo");
    
    var sel = document.getElementById("projects");
    //window.alert(sel.options[sel.selectedIndex].text);
    document.getElementById("address").value = sel.options[sel.selectedIndex].text;
    //document.getElementById("go2res").disabled=false;
}

//document.getElementById("getprname").addEventListener('click', projects);
document.getElementById("projects").addEventListener('change', projects);