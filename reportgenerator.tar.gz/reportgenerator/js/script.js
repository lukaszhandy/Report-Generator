function projects(){
    
    console.log("ala ma kota 40");
    var sel = document.getElementById("projects");
    document.getElementById("address").value = sel.options[sel.selectedIndex].text;
    
    var obj = JSON.parse(document.getElementById("subdirs").value);
    var name = sel.options[sel.selectedIndex].text;
    var i, j;
    var res="";
    var option="";
    var beta = "beta";
    var x = obj[name][0];
    console.log(x);
    document.getElementById("projectsdetails").options.length = 0;
    var sel = document.getElementById("projectsdetails");

    for (j in obj[name]) {
        res += obj[name][j] + "<br>";
        option = document.createElement("option");
        option.text = obj[name][j];
        option.value = obj[name][j];
        sel.add(option);
      }
}
document.getElementById("projects").addEventListener('change', projects);
document.getElementById("projects").addEventListener('click', projects);



